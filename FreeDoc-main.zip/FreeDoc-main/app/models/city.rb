class City < ApplicationRecord
  has_many :appointments

end
